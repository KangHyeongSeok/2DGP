import random
import json
import os
from main_state import collide
from pico2d import *

import game_framework

import result_state


name = "SelectState"
global xpos,ypos,xposA,yposA
xpos,ypos=410,410
xposA,yposA=410,540

font = None
class Select:
    def __init__(self):
        self.image = load_image('monster.png')
        self.x=410
        self.y=339
    def draw(self):
        self.image.draw(self.x,self.y, 485, 80)
class Play:
    def __init__(self):
        self.image = load_image('selectplay.png')
    def draw(self):
        self.image.draw(560,170,100,100)
class Back:
    def __init__(self):
        self.image = load_image('back.png')
    def draw(self):
        self.image.draw(260,170,100,100)
class Ring:
    def __init__(self):
        self.image = load_image('ringblack.png')
        self.x, self.y = xpos, ypos
    def draw(self):
        self.image.draw(408,310,self.x,self.y)
    def update(self):
        self.x+=0.5
        self.y+=0.5
        if self.x > 800 :
            self.x=405
        if self.y > 800 :
            self.y=405
class Background:
    def __init__(self):
        self.image = load_image('backgroundblack.png')

    def draw(self):
        self.image.draw(400, 300)
class Playring:
    def __init__(self):
        self.image = load_image('select.png')

    def draw(self):
        self.image.draw(400, 300,600,600)
def enter():
    global background,playring,ring1, ring2, ring3, ring4,select,play,back
    background = Background()
    playring= Playring()
    ring1 = Ring()
    ring2 = Ring()
    ring3 = Ring()
    ring4 = Ring()
    ring2.x += 120
    ring2.y += 120
    ring3.x += 240
    ring3.y += 240
    ring4.x += 360
    ring4.y += 360
    select= Select()
    play=Play()
    back=Back()




def exit():
    del (play)
    del (select)
    del (playring)
    del (background)
    del (ring1)
    del (ring2)
    del (ring3)
    del (ring4)
    del (back)

def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global mouse_xpos,mouse_ypos
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
            game_framework.push_state(result_state)
        elif event.type == SDL_MOUSEMOTION:
            mouse_xpos, mouse_ypos = event.x, 600 - event.y
            if collide(mouse_xpos, mouse_ypos, 560, 170, 50):
                play.image = load_image('selectplay.png')
            else:
                play.image = load_image('selectplay2.png')
        if event.type == SDL_MOUSEBUTTONDOWN:
            if not collide(mouse_xpos, mouse_ypos, 560, 170, 50):
                game_framework.push_state(result_state)




def update(frame_time):
    ring1.update()
    ring2.update()
    ring3.update()
    ring4.update()



def draw(frame_time):
    global cnt
    clear_canvas()
    background.draw()
    select.draw()
    playring.draw()
    ring1.draw()
    ring2.draw()
    ring3.draw()
    ring4.draw()
    play.draw()
    back.draw()

    update_canvas()








