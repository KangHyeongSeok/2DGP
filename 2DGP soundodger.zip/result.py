import game_framework
from pico2d import *

class Background:
    def __init__(self):
        self.image = load_image('whitebackground.png')

    def draw(self):
        self.image.draw(400, 300)
def enter():
    global background
    background=Background()
def exit():
    del (background)