import random
import json
import os

from pico2d import *

import game_framework
import select_state
import title_state


name = "ResultState"
global xpos,ypos,xposA,yposA
xpos,ypos=410,410
xposA,yposA=410,540

font = None
class Arena:
    def __init__(self):
        self.image = load_image('arena.png')
        self.x, self.y = xposA, yposA
    def draw(self):
        self.image.draw(self.x, self.y,60, 60)
class Ring:
    def __init__(self):
        self.image = load_image('ringblack.png')
        self.x, self.y = xpos, ypos
    def draw(self):
        self.image.draw(408,310,self.x,self.y)
    def update(self):
        self.x+=0.2
        self.y+=0.2
        if self.x > 800 :
            self.x=405
        if self.y > 800 :
            self.y=405
class Background:
    def __init__(self):
        self.image = load_image('backgroundblack.png')

    def draw(self):
        self.image.draw(400, 300)
class Playring:
    def __init__(self):
        self.image = load_image('mainringplay.png')

    def draw(self):
        self.image.draw(400, 300,600,600)
def enter():
    global background,playring,ring1, ring2, ring3, ring4,arena1,arena2,arena3,arena4,arena5,arena6
    background = Background()
    playring= Playring()
    ring1 = Ring()
    ring2 = Ring()
    ring3 = Ring()
    ring4 = Ring()
    ring2.x += 120
    ring2.y += 120
    ring3.x += 240
    ring3.y += 240
    ring4.x += 360
    ring4.y += 360
    arena1=Arena()
    arena2 = Arena()
    arena3 = Arena()
    arena4 = Arena()
    arena5 = Arena()
    arena6 = Arena()
    arena2.x-=190
    arena2.y-=100
    arena3.x += 185
    arena3.y -= 100
    arena4.x -= 190
    arena4.y -= 350
    arena5.x += 185
    arena5.y -= 350
    arena6.y -= 455




def exit():
    del (arena1)
    del (arena2)
    del (arena3)
    del (arena4)
    del (arena5)
    del (arena6)
    del (playring)
    del (background)
    del (ring1)
    del (ring2)
    del (ring3)
    del (ring4)


def pause():
    pass


def resume():
    pass


def handle_events():
    events = get_events()

    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()





def update():
    pass



def draw():
    global cnt
    clear_canvas()
    background.draw()
    playring.draw()
    ring1.draw()
    ring2.draw()
    ring3.draw()
    ring4.draw()
    arena1.draw()
    arena2.draw()
    arena3.draw()
    arena4.draw()
    arena5.draw()
    arena6.draw()
    update_canvas()








