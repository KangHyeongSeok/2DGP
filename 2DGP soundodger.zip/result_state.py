import random
import json
import os
import math
import threading
import time
from pico2d import *

import game_framework
import select_state
import main_state


name = "ResultState"

global xpos,ypos,xposA,yposA,degree,r,xposS,yposS,play_time,delta,number,speed,R,arenadegree,number,Straight_Firstdegree,A,rotatespeed,mouse_xpos,mouse_ypos,flag
flag=False
xposS=200
yposS=200
A=True
count=0
xpos,ypos=290,290
xposA,yposA=410,540
play_time=0
Firstdegree=90
r=227
delta=None
arenanumber=None
speed=None
R=197
rings=None
font = None
arenadegree=None
number=None
Straight_Firstdegree=0
rotatespeed=0
mouse_xpos=0
mouse_ypos=0
class Mouse_cusor:
    def __init__(self):
        self.image = load_image('symbol_round.png')
        self.x=mouse_xpos
        self.y=mouse_ypos
    def update(self):
        if not collide(mouse_xpos,mouse_ypos,408,310,200):
            self.x,self.y=mouse_xpos,mouse_ypos


    def draw(self):
        self.image.draw(self.x, self.y,20, 20)
class Arena:
    def __init__(self):
        self.image = load_image('arena.png')
        self.degree=Firstdegree
        self.x, self.y = (r*math.cos(math.radians(self.degree)))+408,(r*math.sin(math.radians(self.degree)))+313
        xposS=self.x
        yposS=self.y
    def update(self):
        self.degree-=rotatespeed
        self.x, self.y = (r * math.cos(math.radians(self.degree))) + 408, (r * math.sin(math.radians(self.degree))) + 313
    def draw(self):
        self.image.draw(self.x, self.y,60, 60)
class Straight:
    def __init__(self):
        self.image=load_image('triangle.png')
        self.degree=Straight_Firstdegree
        self.x,self.y=(R * math.cos(math.radians(self.degree))) + 408, (R * math.sin(math.radians(self.degree))) + 313
    def draw(self):
        self.image.draw(self.x, self.y, 40, 40)

    def update(self):
        self.x+=self.speed*self.deltaX
        self.y+=self.speed*self.deltaY
def drawstraight(arenanumber,deltaY,deltaX,speed,straight_interval,A):
    global allofstraight,Straight_Firstdegree,count
    if count==1:
        if A==True:
            Straight_Firstdegree = 0
            if arenanumber==1:
                Straight_Firstdegree+=arena1_degree
            elif arenanumber==2:
                Straight_Firstdegree += arena2_degree
            elif arenanumber==3:
                Straight_Firstdegree += arena3_degree
            elif arenanumber==4:
                Straight_Firstdegree += arena4_degree
            elif arenanumber==5:
                Straight_Firstdegree += arena5_degree
            elif arenanumber==6:
                Straight_Firstdegree += arena6_degree
            elif arenanumber==7:
                Straight_Firstdegree += arena7_degree
            elif arenanumber==8:
                Straight_Firstdegree += arena8_degree
        elif A==False:
            Straight_Firstdegree = 0
            if arenanumber==1:
                Straight_Firstdegree+=90
            elif arenanumber==2:
                Straight_Firstdegree += 135
            elif arenanumber==3:
                Straight_Firstdegree += 180
            elif arenanumber==4:
                Straight_Firstdegree += 225
            elif arenanumber==5:
                Straight_Firstdegree += 270
            elif arenanumber==6:
                Straight_Firstdegree += 315
            elif arenanumber==7:
                Straight_Firstdegree += 0
            elif arenanumber==8:
                Straight_Firstdegree += 45
        straights = [Straight()]
        for straight in straights:
            straight.speed=speed
            straight.deltaY=deltaY
            straight.deltaX = deltaX



        allofstraight=allofstraight+straights
    count+=1
    if count>straight_interval:
        count=0


def collide(x1,y1,x2,y2,r):
    if (math.sqrt(((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1))))>r:
        return True
    else:
        return False

class Ring:
    def __init__(self):
        self.image = load_image('ringblack.png')
        self.x, self.y = xpos,ypos

    def draw(self):
        self.image.draw(408,310,self.x,self.y)
    def update(self):
        self.x+=0.5
        self.y+=0.5
        if self.x > 800 :
            self.x=405
        if self.y > 800 :
            self.y=405

class Background:
    def __init__(self):
        self.image = load_image('backgroundblack.png')
    def draw(self):

        self.image.draw(400, 300)
class Playring:
    def __init__(self):
        self.image = load_image('mainringplay.png')

    def draw(self):
        self.image.draw(400, 300,600,600)
def enter():
    global background,playring,arena1,arena2,arena3,arena4,arena5,arena6,arena7,arena8,rings,interval,arenas,Firstdegree,allofstraight,Straight_Firstdegree,B,C,cursor
    background = Background()
    playring= Playring()
    cursor=Mouse_cusor()
    hide_cursor()
    B=1
    C=1
    interval=120
    ADD_DGREE=45
    allofstraight=[]
    rings= [Ring() for i in range(3)]
    for ring in rings:
        ring.x+=interval
        ring.y+=interval
        interval+=120
    arena1=Arena()
    Firstdegree += ADD_DGREE
    arena2=Arena()
    Firstdegree += ADD_DGREE
    arena3=Arena()
    Firstdegree += ADD_DGREE
    arena4=Arena()
    Firstdegree += ADD_DGREE
    arena5=Arena()
    Firstdegree += ADD_DGREE
    arena6=Arena()
    Firstdegree += ADD_DGREE
    arena7 = Arena()
    Firstdegree += ADD_DGREE
    arena8 = Arena()
    Firstdegree = 90
    arenas=[arena1,arena2,arena3,arena4,arena5,arena6,arena7,arena8]






def exit():
    del(rings)
    del (arenas)
    del (arena1)
    del (arena2)
    del (arena3)
    del (arena4)
    del (arena5)
    del (arena6)
    del (arena7)
    del (arena8)
    del (playring)
    del (background)



def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global mouse_xpos,mouse_ypos,flag
    events = get_events()

    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_MOUSEMOTION:
            mouse_xpos, mouse_ypos = event.x, 600 - event.y
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
            if flag:
                flag=False
            elif not flag:
                flag=True
            #game_framework.push_state(result_state)





def update(frame_time):
    global play_time,arena1_degree,arena2_degree,arena3_degree,arena4_degree,arena5_degree,arena6_degree,arena7_degree,arena8_degree,A,B,C,rotatespeed,Straight_Firstdegree,result
    play_time=0

    for ring in rings:
        ring.update()
    for arena in arenas:
        if (play_time>=20)and(play_time<28.9):
            rotatespeed=0.2
        elif (play_time>=30.3)and(play_time<30.8):
            rotatespeed=3
        elif (play_time>=30.8)and(play_time<34.2):
            rotatespeed=0.2
        elif (play_time>=34.2)and(play_time<34.6):
            rotatespeed=2
        elif (play_time>=34.6)and(play_time<34.8):
            rotatespeed=0.2
        elif (play_time>=34.8)and(play_time<35.3):
            rotatespeed=2
        elif (play_time>=35.3)and(play_time<35.8):
            rotatespeed=0.2
        elif (play_time>=35.8)and(play_time<36.35):
            rotatespeed=2
        elif (play_time>=36.35)and(play_time<36.7):
            rotatespeed=0.2
        elif (play_time>=36.7)and(play_time<37.25):
            rotatespeed=2
        elif (play_time>=37.25)and(play_time<37.6):
            rotatespeed=0.2
        elif (play_time>=37.8)and(play_time<38.2):
            rotatespeed=3
        elif (play_time>=38.2)and(play_time<38.5):
            rotatespeed=0.2
        elif (play_time>=38.5)and(play_time<39.0):
            rotatespeed=2
        elif (play_time>=39)and(play_time<41.7):
            rotatespeed=0.2
        elif (play_time>=41.7)and(play_time<42.2):
            rotatespeed=3
        elif (play_time>=42.2)and(play_time<42.4):
            rotatespeed=0.2
        elif (play_time>=42.4)and(play_time<42.9):
            rotatespeed=3
        elif (play_time>=42.9)and(play_time<43.4):
            rotatespeed=0.2
        elif (play_time>=43.4)and(play_time<43.8):
            rotatespeed=1
        elif (play_time>=43.8)and(play_time<44.1):
            rotatespeed=0.2
        elif (play_time >= 44.1) and (play_time < 44.6):
            rotatespeed = 1
        elif (play_time >= 44.6) and (play_time < 49.2):
            rotatespeed = 0.2
        elif (play_time>=49.2)and(play_time<49.6):
            rotatespeed=3
        elif (play_time>=49.6)and(play_time<49.8):
            rotatespeed=0.2
        elif (play_time>=49.8)and(play_time<50.5):
            rotatespeed=3
        elif (play_time>=50.5):
            rotatespeed=0.1
        else:
            rotatespeed=0
        arena.update()
    arena1_degree=arena1.degree
    arena2_degree=arena2.degree
    arena3_degree = arena3.degree
    arena4_degree = arena4.degree
    arena5_degree = arena5.degree
    arena6_degree = arena6.degree
    arena7_degree = arena7.degree
    arena8_degree = arena8.degree

    if (play_time>=8)and(play_time<10):
        drawstraight(1,-1,1, 1.5,10,False)
        drawstraight(3, 1,1, 1.5,10,False)
        drawstraight(5, -1,1, -1.5,10,False)
        drawstraight(7, 1, 1,-1.5,10,False)
    elif (play_time>=15.5)and(play_time<17.5):
        drawstraight(1,-1, 1,1.5,10,False)
        drawstraight(3, 1, 1,1.5,10,False)
        drawstraight(5, -1, 1,-1.5,10,False)
        drawstraight(7, 1, 1,-1.5,10,False)
    elif (play_time>=23)and(play_time<25):
        drawstraight(1, -2, 1,1.5, 10, False)
        drawstraight(3, 0.5, 1,3, 10, False)
        drawstraight(5, -2, 1,-1.5, 10, False)
        drawstraight(7, 0.5, 1,-3, 10, False)
    elif (play_time>=26.7)and(play_time<28.7):
        drawstraight(1, -4, 1,1.5, 10, False)
        drawstraight(3, 0.3, 1,3, 10, False)
        drawstraight(5, -4, 1,-1.5, 10, False)
        drawstraight(7, 0.3, 1,-3, 10, False)
    elif (play_time>=30.5)and(play_time<32.5):
        drawstraight(1, 1, 1,-2, 10, False)
        drawstraight(3, -1, 1,2, 10, False)
        drawstraight(5, 1, 1,2, 10, False)
        drawstraight(7, -1, 1,-2, 10, False)
        drawstraight(2, -1, 0,2, 10, False)
        drawstraight(4, 0, 1,2, 10, False)
        drawstraight(6, -1, 0,-2, 10, False)
        drawstraight(8, 0, 1,-2, 10, False)
    elif (play_time >= 34.2) and (play_time < 35.2):
        drawstraight(1, -3, 1, 1, 10, False)
        drawstraight(3, -0.3, 1, 2.5, 10, False)
        drawstraight(5, -3, 1, -1, 10, False)
        drawstraight(7, -0.3, 1, -2.5, 10, False)
    if (play_time >= 34.2) and (play_time < 35.2):
        drawstraight(3, -2, 1, 1, 10, False)
        drawstraight(4, -2, 1, -1, 10, False)
        drawstraight(7, -2, 1, -1, 10, False)
        drawstraight(8, -2, 1, 1, 10, False)
    elif (play_time >= 35.8) and (play_time < 36.35):
        drawstraight(2,-1.5,1,2,2,True)
    elif (play_time >= 36.7) and (play_time < 37.25):
        drawstraight(1,-1.5,1,-2,2,True)
    elif (play_time >= 37.8) and (play_time < 38.5):
        drawstraight(1, -3, 1, 1, 10, False)
        drawstraight(3, -0.3, 1, 2.5, 10, False)
        drawstraight(5, -3, 1, -1, 10, False)
        drawstraight(7, -0.3, 1, -2.5, 10, False)
    elif (play_time >= 38.5) and (play_time < 40):
        drawstraight(3, -2, 1, 1, 10, False)
        drawstraight(4, -2, 1, -1, 10, False)
        drawstraight(7, -2, 1, -1, 10, False)
        drawstraight(8, -2, 1, 1, 10, False)
    elif (play_time >= 40) and (play_time < 40.1):
        drawstraight(3, -0.5, 1, 1, 10, False)
        drawstraight(3, 0, 1, 1, 10, False)
        drawstraight(3, 0.5, 1, 1, 10, False)
        drawstraight(3, -1, 1, 1, 10, False)
        drawstraight(7, -0.5, 1, -1, 10, False)
        drawstraight(7, 0, 1, -1, 10, False)
        drawstraight(7, 0.5, 1, -1, 10, False)
        drawstraight(7, -1, 1, -1, 10, False)
    if (play_time >= 40.1) and (play_time < 40.2):
        drawstraight(1, -1, 1, 1, 10, False)
        drawstraight(1, -3, 1, 1, 10, False)
        drawstraight(1, 1, 0, -1, 10, False)
        drawstraight(1, 3, 1, -1, 10, False)
        drawstraight(5, -1, 1, 1, 10, False)
        drawstraight(5, -3, 1, 1, 10, False)
        drawstraight(5, 1, 0, 1, 10, False)
        drawstraight(5, 1, 1, 1, 10, False)
    elif (play_time >= 41.7) and (play_time < 45.4):
        drawstraight(8,0.5,1,-2,10,False)
        drawstraight(8, 2,1,-1,10,False)
        drawstraight(7,-0.5,1,-2,10,False)
        drawstraight(7,0.5,1,-2,10,False)
        drawstraight(6,-2,1,-1,10,False)
        drawstraight(6,-0.5,1,-2,10,False)
        drawstraight(5,2,1,1,10,False)
        drawstraight(5,-2,1,-1,10,False)
        drawstraight(4,0.5,1,2,10,False)
        drawstraight(4,2,1,1,10,False)
        drawstraight(3,-0.5,1,2,10,False)
        drawstraight(3,0.5,1,2,10,False)
        drawstraight(2,-2,1,1,10,False)
        drawstraight(2,-0.5,1,2,10,False)
        drawstraight(1,2,1,-1,10,False)
        drawstraight(1,-2,1,1,10,False)
    if (play_time >= 45.5) and (play_time < 45.7):
        drawstraight(8, 1, 0, -0.5, 10, False)
        drawstraight(2, -3, 1, 0.3, 10, False)
    elif (play_time >= 45.9) and (play_time < 46.1):
        drawstraight(4, 1, 1, 0.5, 10, False)
        drawstraight(6, -1.1, 1, -0.5, 10, False)
    elif (play_time >= 46.3) and (play_time < 46.5):
        drawstraight(1, 2, 1, -0.3, 10, False)
        drawstraight(3, 1.2, 1, 0.5, 10, False)
    elif (play_time >= 46.7) and (play_time < 46.9):
        drawstraight(5, -2, 1, -0.3, 10, False)
        drawstraight(7, -0.5, 1, -0.5, 10, False)
    elif (play_time >= 47.1) and (play_time < 47.3):
        drawstraight(3, -0.3, 1, 0.6, 10, False)
        drawstraight(4, 0.3, 1, 0.5, 10, False)
    elif (play_time >= 47.4) and (play_time < 47.6):
        drawstraight(3, 0.3, 1, 0.6, 10, False)
        drawstraight(4, 0.6, 1, 0.5, 10, False)
    elif (play_time >= 47.6) and (play_time < 47.7):
        drawstraight(2, 0, 1, 1, 10, False)
    elif (play_time >= 47.8) and (play_time < 47.9):
        drawstraight(2, -0.5, 1, 1, 10, False)
    elif (play_time >= 47.9) and (play_time < 48):
        drawstraight(2, -1, 1, 1, 10, False)
    elif (play_time >= 48) and (play_time < 48.1):
        drawstraight(2, -1.5, 1, 0.8, 10, False)
    elif (play_time >= 48.1) and (play_time < 48.2):
        drawstraight(2, -2, 1, 0.5, 10, False)
    if (play_time >= 49.2) and (play_time < 49.8):
        drawstraight(2,-3,1,1,5,False)
    elif (play_time >= 49.8) and (play_time < 50.5):
        drawstraight(6,-3,1,-1,5,False)
    elif (play_time >= 50.7) and (play_time < 52.2):
        drawstraight(2, -0.7, 1, 2, 5, False)










    for straight in allofstraight:
        straight.update()
        if not collide(mouse_xpos,mouse_ypos,straight.x,straight.y,20):
            straight.image=load_image('triangle2.png')

        if collide(408,310,straight.x,straight.y,220):
            allofstraight.remove(straight)
    cursor.update()












def draw(frame_time):
    global cnt
    clear_canvas()
    background.draw()
    playring.draw()
    for ring in rings:
        ring.draw()
    for arena in arenas:
        arena.draw()
    for straight in allofstraight:
        straight.draw()
    cursor.draw()
    update_canvas()








import random
import json
import os
import math
import threading
import time
from pico2d import *

import game_framework

import main_state


name = "MainState"


flag=False
xposS=200
yposS=200
A=True
count=0
xpos,ypos=290,290
xposA,yposA=410,540
play_time=0
Firstdegree=90
r=227
delta=None
arenanumber=None
speed=None
R=197
rings=None
font = None
arenadegree=None
number=None
Straight_Firstdegree=0
rotatespeed=0
mouse_xpos=0
mouse_ypos=0
class Mouse_cusor:
    def __init__(self):
        self.image = load_image('symbol_round.png')
        self.x=mouse_xpos
        self.y=mouse_ypos
    def update(self):
        if not collide(mouse_xpos,mouse_ypos,408,310,200):
            self.x,self.y=mouse_xpos,mouse_ypos


    def draw(self):
        self.image.draw(self.x, self.y,20, 20)
class Arena:
    def __init__(self):
        self.image = load_image('arena.png')
        self.degree=Firstdegree
        self.x, self.y = (r*math.cos(math.radians(self.degree)))+408,(r*math.sin(math.radians(self.degree)))+313
        xposS=self.x
        yposS=self.y
    def update(self):
        self.degree-=rotatespeed
        self.x, self.y = (r * math.cos(math.radians(self.degree))) + 408, (r * math.sin(math.radians(self.degree))) + 313
    def draw(self):
        self.image.draw(self.x, self.y,60, 60)
class Straight:
    def __init__(self):
        self.image=load_image('triangle.png')
        self.degree=Straight_Firstdegree
        self.x,self.y=(R * math.cos(math.radians(self.degree))) + 408, (R * math.sin(math.radians(self.degree))) + 313
    def draw(self):
        self.image.draw(self.x, self.y, 40, 40)

    def update(self):
        self.x+=self.speed*self.deltaX
        self.y+=self.speed*self.deltaY
def drawstraight(arenanumber,deltaY,deltaX,speed,straight_interval,A):
    global allofstraight,Straight_Firstdegree,count
    if count==1:
        if A==True:
            Straight_Firstdegree = 0
            if arenanumber==1:
                Straight_Firstdegree+=arena1_degree
            elif arenanumber==2:
                Straight_Firstdegree += arena2_degree
            elif arenanumber==3:
                Straight_Firstdegree += arena3_degree
            elif arenanumber==4:
                Straight_Firstdegree += arena4_degree
            elif arenanumber==5:
                Straight_Firstdegree += arena5_degree
            elif arenanumber==6:
                Straight_Firstdegree += arena6_degree
            elif arenanumber==7:
                Straight_Firstdegree += arena7_degree
            elif arenanumber==8:
                Straight_Firstdegree += arena8_degree
        elif A==False:
            Straight_Firstdegree = 0
            if arenanumber==1:
                Straight_Firstdegree+=90
            elif arenanumber==2:
                Straight_Firstdegree += 135
            elif arenanumber==3:
                Straight_Firstdegree += 180
            elif arenanumber==4:
                Straight_Firstdegree += 225
            elif arenanumber==5:
                Straight_Firstdegree += 270
            elif arenanumber==6:
                Straight_Firstdegree += 315
            elif arenanumber==7:
                Straight_Firstdegree += 0
            elif arenanumber==8:
                Straight_Firstdegree += 45
        straights = [Straight()]
        for straight in straights:
            straight.speed=speed
            straight.deltaY=deltaY
            straight.deltaX = deltaX



        allofstraight=allofstraight+straights
    count+=1
    if count>straight_interval:
        count=0


def collide(x1,y1,x2,y2,r):
    if (math.sqrt(((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1))))>r:
        return True
    else:
        return False

class Ring:
    def __init__(self):
        self.image = load_image('ringblack.png')
        self.x, self.y = xpos,ypos

    def draw(self):
        self.image.draw(408,310,self.x,self.y)
    def update(self):
        self.x+=0.5
        self.y+=0.5
        if self.x > 800 :
            self.x=405
        if self.y > 800 :
            self.y=405

class Background:
    def __init__(self):
        self.image = load_image('backgroundblack.png')


    def draw(self):

        self.image.draw(400, 300)
class Playring:
    def __init__(self):
        self.image = load_image('mainringplay.png')

    def draw(self):
        self.image.draw(400, 300,600,600)
def enter():
    global background,playring,arena1,arena2,arena3,arena4,arena5,arena6,arena7,arena8,rings,interval,arenas,Firstdegree,allofstraight,Straight_Firstdegree,B,C,cursor
    background = Background()
    playring= Playring()
    cursor=Mouse_cusor()
    hide_cursor()
    B=1
    C=1
    interval=120
    ADD_DGREE=45
    allofstraight=[]
    rings= [Ring() for i in range(3)]
    for ring in rings:
        ring.x+=interval
        ring.y+=interval
        interval+=120
    arena1=Arena()
    Firstdegree += ADD_DGREE
    arena2=Arena()
    Firstdegree += ADD_DGREE
    arena3=Arena()
    Firstdegree += ADD_DGREE
    arena4=Arena()
    Firstdegree += ADD_DGREE
    arena5=Arena()
    Firstdegree += ADD_DGREE
    arena6=Arena()
    Firstdegree += ADD_DGREE
    arena7 = Arena()
    Firstdegree += ADD_DGREE
    arena8 = Arena()
    Firstdegree = 90
    arenas=[arena1,arena2,arena3,arena4,arena5,arena6,arena7,arena8]






def exit():
    del(rings)
    del (arenas)
    del (arena1)
    del (arena2)
    del (arena3)
    del (arena4)
    del (arena5)
    del (arena6)
    del (arena7)
    del (arena8)
    del (playring)
    del (background)



def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global mouse_xpos,mouse_ypos,flag
    events = get_events()

    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_MOUSEMOTION:
            mouse_xpos, mouse_ypos = event.x, 600 - event.y
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
            if flag:
                flag=False
            elif not flag:
                flag=True
            game_framework.push_state(main_state)





def update(frame_time):
    global play_time,arena1_degree,arena2_degree,arena3_degree,arena4_degree,arena5_degree,arena6_degree,arena7_degree,arena8_degree,A,B,C,rotatespeed,Straight_Firstdegree,result
    play_time=0

    for ring in rings:
        ring.update()
    for arena in arenas:
        if (play_time>=20)and(play_time<28.9):
            rotatespeed=0.2
        elif (play_time>=30.3)and(play_time<30.8):
            rotatespeed=3
        elif (play_time>=30.8)and(play_time<34.2):
            rotatespeed=0.2
        elif (play_time>=34.2)and(play_time<34.6):
            rotatespeed=2
        elif (play_time>=34.6)and(play_time<34.8):
            rotatespeed=0.2
        elif (play_time>=34.8)and(play_time<35.3):
            rotatespeed=2
        elif (play_time>=35.3)and(play_time<35.8):
            rotatespeed=0.2
        elif (play_time>=35.8)and(play_time<36.35):
            rotatespeed=2
        elif (play_time>=36.35)and(play_time<36.7):
            rotatespeed=0.2
        elif (play_time>=36.7)and(play_time<37.25):
            rotatespeed=2
        elif (play_time>=37.25)and(play_time<37.6):
            rotatespeed=0.2
        elif (play_time>=37.8)and(play_time<38.2):
            rotatespeed=3
        elif (play_time>=38.2)and(play_time<38.5):
            rotatespeed=0.2
        elif (play_time>=38.5)and(play_time<39.0):
            rotatespeed=2
        elif (play_time>=39)and(play_time<41.7):
            rotatespeed=0.2
        elif (play_time>=41.7)and(play_time<42.2):
            rotatespeed=3
        elif (play_time>=42.2)and(play_time<42.4):
            rotatespeed=0.2
        elif (play_time>=42.4)and(play_time<42.9):
            rotatespeed=3
        elif (play_time>=42.9)and(play_time<43.4):
            rotatespeed=0.2
        elif (play_time>=43.4)and(play_time<43.8):
            rotatespeed=1
        elif (play_time>=43.8)and(play_time<44.1):
            rotatespeed=0.2
        elif (play_time >= 44.1) and (play_time < 44.6):
            rotatespeed = 1
        elif (play_time >= 44.6) and (play_time < 49.2):
            rotatespeed = 0.2
        elif (play_time>=49.2)and(play_time<49.6):
            rotatespeed=3
        elif (play_time>=49.6)and(play_time<49.8):
            rotatespeed=0.2
        elif (play_time>=49.8)and(play_time<50.5):
            rotatespeed=3
        elif (play_time>=50.5):
            rotatespeed=0.1
        else:
            rotatespeed=0
        arena.update()
    arena1_degree=arena1.degree
    arena2_degree=arena2.degree
    arena3_degree = arena3.degree
    arena4_degree = arena4.degree
    arena5_degree = arena5.degree
    arena6_degree = arena6.degree
    arena7_degree = arena7.degree
    arena8_degree = arena8.degree

    if (play_time>=8)and(play_time<10):
        drawstraight(1,-1,1, 1.5,10,False)
        drawstraight(3, 1,1, 1.5,10,False)
        drawstraight(5, -1,1, -1.5,10,False)
        drawstraight(7, 1, 1,-1.5,10,False)
    elif (play_time>=15.5)and(play_time<17.5):
        drawstraight(1,-1, 1,1.5,10,False)
        drawstraight(3, 1, 1,1.5,10,False)
        drawstraight(5, -1, 1,-1.5,10,False)
        drawstraight(7, 1, 1,-1.5,10,False)
    elif (play_time>=23)and(play_time<25):
        drawstraight(1, -2, 1,1.5, 10, False)
        drawstraight(3, 0.5, 1,3, 10, False)
        drawstraight(5, -2, 1,-1.5, 10, False)
        drawstraight(7, 0.5, 1,-3, 10, False)
    elif (play_time>=26.7)and(play_time<28.7):
        drawstraight(1, -4, 1,1.5, 10, False)
        drawstraight(3, 0.3, 1,3, 10, False)
        drawstraight(5, -4, 1,-1.5, 10, False)
        drawstraight(7, 0.3, 1,-3, 10, False)
    elif (play_time>=30.5)and(play_time<32.5):
        drawstraight(1, 1, 1,-2, 10, False)
        drawstraight(3, -1, 1,2, 10, False)
        drawstraight(5, 1, 1,2, 10, False)
        drawstraight(7, -1, 1,-2, 10, False)
        drawstraight(2, -1, 0,2, 10, False)
        drawstraight(4, 0, 1,2, 10, False)
        drawstraight(6, -1, 0,-2, 10, False)
        drawstraight(8, 0, 1,-2, 10, False)
    elif (play_time >= 34.2) and (play_time < 35.2):
        drawstraight(1, -3, 1, 1, 10, False)
        drawstraight(3, -0.3, 1, 2.5, 10, False)
        drawstraight(5, -3, 1, -1, 10, False)
        drawstraight(7, -0.3, 1, -2.5, 10, False)
    if (play_time >= 34.2) and (play_time < 35.2):
        drawstraight(3, -2, 1, 1, 10, False)
        drawstraight(4, -2, 1, -1, 10, False)
        drawstraight(7, -2, 1, -1, 10, False)
        drawstraight(8, -2, 1, 1, 10, False)
    elif (play_time >= 35.8) and (play_time < 36.35):
        drawstraight(2,-1.5,1,2,2,True)
    elif (play_time >= 36.7) and (play_time < 37.25):
        drawstraight(1,-1.5,1,-2,2,True)
    elif (play_time >= 37.8) and (play_time < 38.5):
        drawstraight(1, -3, 1, 1, 10, False)
        drawstraight(3, -0.3, 1, 2.5, 10, False)
        drawstraight(5, -3, 1, -1, 10, False)
        drawstraight(7, -0.3, 1, -2.5, 10, False)
    elif (play_time >= 38.5) and (play_time < 40):
        drawstraight(3, -2, 1, 1, 10, False)
        drawstraight(4, -2, 1, -1, 10, False)
        drawstraight(7, -2, 1, -1, 10, False)
        drawstraight(8, -2, 1, 1, 10, False)
    elif (play_time >= 40) and (play_time < 40.1):
        drawstraight(3, -0.5, 1, 1, 10, False)
        drawstraight(3, 0, 1, 1, 10, False)
        drawstraight(3, 0.5, 1, 1, 10, False)
        drawstraight(3, -1, 1, 1, 10, False)
        drawstraight(7, -0.5, 1, -1, 10, False)
        drawstraight(7, 0, 1, -1, 10, False)
        drawstraight(7, 0.5, 1, -1, 10, False)
        drawstraight(7, -1, 1, -1, 10, False)
    if (play_time >= 40.1) and (play_time < 40.2):
        drawstraight(1, -1, 1, 1, 10, False)
        drawstraight(1, -3, 1, 1, 10, False)
        drawstraight(1, 1, 0, -1, 10, False)
        drawstraight(1, 3, 1, -1, 10, False)
        drawstraight(5, -1, 1, 1, 10, False)
        drawstraight(5, -3, 1, 1, 10, False)
        drawstraight(5, 1, 0, 1, 10, False)
        drawstraight(5, 1, 1, 1, 10, False)
    elif (play_time >= 41.7) and (play_time < 45.4):
        drawstraight(8,0.5,1,-2,10,False)
        drawstraight(8, 2,1,-1,10,False)
        drawstraight(7,-0.5,1,-2,10,False)
        drawstraight(7,0.5,1,-2,10,False)
        drawstraight(6,-2,1,-1,10,False)
        drawstraight(6,-0.5,1,-2,10,False)
        drawstraight(5,2,1,1,10,False)
        drawstraight(5,-2,1,-1,10,False)
        drawstraight(4,0.5,1,2,10,False)
        drawstraight(4,2,1,1,10,False)
        drawstraight(3,-0.5,1,2,10,False)
        drawstraight(3,0.5,1,2,10,False)
        drawstraight(2,-2,1,1,10,False)
        drawstraight(2,-0.5,1,2,10,False)
        drawstraight(1,2,1,-1,10,False)
        drawstraight(1,-2,1,1,10,False)
    if (play_time >= 45.5) and (play_time < 45.7):
        drawstraight(8, 1, 0, -0.5, 10, False)
        drawstraight(2, -3, 1, 0.3, 10, False)
    elif (play_time >= 45.9) and (play_time < 46.1):
        drawstraight(4, 1, 1, 0.5, 10, False)
        drawstraight(6, -1.1, 1, -0.5, 10, False)
    elif (play_time >= 46.3) and (play_time < 46.5):
        drawstraight(1, 2, 1, -0.3, 10, False)
        drawstraight(3, 1.2, 1, 0.5, 10, False)
    elif (play_time >= 46.7) and (play_time < 46.9):
        drawstraight(5, -2, 1, -0.3, 10, False)
        drawstraight(7, -0.5, 1, -0.5, 10, False)
    elif (play_time >= 47.1) and (play_time < 47.3):
        drawstraight(3, -0.3, 1, 0.6, 10, False)
        drawstraight(4, 0.3, 1, 0.5, 10, False)
    elif (play_time >= 47.4) and (play_time < 47.6):
        drawstraight(3, 0.3, 1, 0.6, 10, False)
        drawstraight(4, 0.6, 1, 0.5, 10, False)
    elif (play_time >= 47.6) and (play_time < 47.7):
        drawstraight(2, 0, 1, 1, 10, False)
    elif (play_time >= 47.8) and (play_time < 47.9):
        drawstraight(2, -0.5, 1, 1, 10, False)
    elif (play_time >= 47.9) and (play_time < 48):
        drawstraight(2, -1, 1, 1, 10, False)
    elif (play_time >= 48) and (play_time < 48.1):
        drawstraight(2, -1.5, 1, 0.8, 10, False)
    elif (play_time >= 48.1) and (play_time < 48.2):
        drawstraight(2, -2, 1, 0.5, 10, False)
    if (play_time >= 49.2) and (play_time < 49.8):
        drawstraight(2,-3,1,1,5,False)
    elif (play_time >= 49.8) and (play_time < 50.5):
        drawstraight(6,-3,1,-1,5,False)
    elif (play_time >= 50.7) and (play_time < 52.2):
        drawstraight(2, -0.7, 1, 2, 5, False)
    elif (play_time >= 52.4) and (play_time < 53.9):
        drawstraight(7, 0.7, 1, -2, 5, False)










    for straight in allofstraight:
        straight.update()
        if not collide(mouse_xpos,mouse_ypos,straight.x,straight.y,20):
            straight.image=load_image('triangle2.png')

        if collide(408,310,straight.x,straight.y,220):
            allofstraight.remove(straight)
    cursor.update()












def draw(frame_time):
    global cnt
    clear_canvas()
    background.draw()
    playring.draw()
    for ring in rings:
        ring.draw()
    for arena in arenas:
        arena.draw()
    for straight in allofstraight:
        straight.draw()
    cursor.draw()
    update_canvas()








