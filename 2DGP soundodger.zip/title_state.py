import game_framework
import select_state
from pico2d import *
from main_state import collide

name = "TitleState"
image = None
global xpos,ypos
xpos,ypos=300,300

font = None
class Background:
    def __init__(self):
        self.image = load_image('whitebackground.png')

    def draw(self):
        self.image.draw(400, 300)
class Playicon:
    def __init__(self):
        self.image = load_image('soundoger play.png')
    def draw(self):
        self.image.draw(600, 260,150,150)
class Userlevelicon:
    def __init__(self):
        self.image = load_image('soundoger userlevel.png')
    def draw(self):
        self.image.draw(150, 300,150,150)
class Ring:
    def __init__(self):
        self.image = load_image('ring.png')
        self.x, self.y = xpos, ypos
    def draw(self):
        self.image.draw(400,500,self.x,self.y)
    def update(self):
        self.x+=0.2
        self.y+=0.2
        if self.x > 1400 :
            self.x=300
        if self.y > 1400 :
            self.y=300
class Mainring:
    def __init__(self):
        self.image = load_image('mainring.png')
        self.x,self.y=500,500
    def draw(self):
        self.image.draw(400, 500, self.x, self.y)


def enter():
    global PA, pause, cnt, background, ring1, ring2, ring3, ring4, ring5, mainring, play, userlevel
    play=Playicon()
    userlevel=Userlevelicon()
    ring1 = Ring()
    ring2 = Ring()
    ring3 = Ring()
    ring4 = Ring()
    ring5 = Ring()
    ring2.x += 280
    ring2.y += 280
    ring3.x += 560
    ring3.y += 560
    ring4.x += 840
    ring4.y += 840
    ring5.x += 1120
    ring5.y += 1120

    mainring = Mainring()
    background = Background()


def exit():
    del (play)
    del (userlevel)
    del (mainring)
    del (ring1)
    del (ring2)
    del (ring3)
    del (ring4)
    del (ring5)
    del (background)


def handle_events(frame_time):
    global mouse_xpos,mouse_ypos
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
                game_framework.push_state(select_state)
            elif event.type == SDL_MOUSEMOTION:
                mouse_xpos, mouse_ypos = event.x, 600 - event.y
                if collide(mouse_xpos,mouse_ypos,600,260,75):
                    play.image=load_image('soundoger play.png')
                else:
                    play.image = load_image('soundoger play2.png')
                if collide(mouse_xpos,mouse_ypos,150,300,75):
                    userlevel.image=load_image('soundoger userlevel.png')
                else:
                    userlevel.image = load_image('soundoger userlevel2.png')
            if event.type == SDL_MOUSEBUTTONDOWN:
                if not collide(mouse_xpos, mouse_ypos, 600, 260, 75):
                    game_framework.push_state(select_state)


def draw(frame_time):
    global cnt
    clear_canvas()
    background.draw()
    ring1.draw()
    ring2.draw()
    ring3.draw()
    ring4.draw()
    ring5.draw()
    mainring.draw()
    play.draw()
    userlevel.draw()


    update_canvas()


def update(frame_time):
    global cnt
    ring1.update()
    ring2.update()
    ring3.update()
    ring4.update()
    ring5.update()


def pause():
    pass


def resume():
    pass






